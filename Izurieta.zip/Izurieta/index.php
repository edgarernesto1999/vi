<?php

include 'models/conexion.php';
include 'models/guardar.php';       
include 'models/logica_editar.php'; 
include 'models/vender.php';        
include 'models/eliminar.php';
include 'models/buscar.php'; 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title> Tienda</title>
</head>
<body>

    <h1>Tienda</h1>

    <?php if (!empty($mensaje)): ?>
        <center>
            <?php echo $mensaje; ?>
        </center>
        <br>
    <?php endif; ?>

    <table width="100%" border="0">
        <tr>
            <td width="50%" valign="top">
                <fieldset>
                    <legend><strong>INGRESO DE MERCADERÍA</strong></legend>
                    <form method="POST" action="index.php">
                        <input type="hidden" name="accion" value="guardar">
                        
                        <label>Producto:</label><br>
                        <input type="text" name="nombre" placeholder="Ej. Papas" required><br>
                        
                        <label>Cantidad a Sumar:</label><br>
                        <input type="number" name="cantidad" placeholder="0" required min="1"><br>
                        
                        <label>Precio Unitario (Actualizar):</label><br>
                        <input type="number" step="0.01" name="precio" placeholder="0.00" required min="0"><br><br>
                        
                        <button type="submit">Agregar</button>
                    </form>
                </fieldset>
            </td>

            <td width="50%" valign="top">
                <fieldset>
                    <legend><strong>CAJA REGISTRADORA (Vender)</strong></legend>
                    <form method="POST" action="index.php">
                        <input type="hidden" name="accion" value="vender">
                        
                        <label>Nombre del Producto a Vender:</label><br>
                        <input type="text" name="nombre" placeholder="Ej. Papas" required><br>
                        
                        <label>Cantidad a Vender:</label><br>
                        <input type="number" name="cantidad" placeholder="0" required min="1"><br><br>
                        
                        <br>
                        
                        <button type="submit">Realizar Venta</button>
                    </form>
                </fieldset>
            </td>
        </tr>
    </table>

    <hr>

    <form method="GET" action="index.php">
        <label>Buscar</label>
        <input type="text" name="busqueda" value="<?php echo htmlspecialchars($busqueda); ?>">
        <button type="submit">Filtrar</button>
        <?php if($busqueda): ?>
            <a href="index.php">[Ver Todo]</a>
        <?php endif; ?>
    </form>

    <br>

    <table>
        <thead>
            <tr>
                <th>Nombre del Producto</th>
                <th>Precio Unit.</th>
                <th>Stock Disponible</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($resultado) > 0): ?>
                <?php while($fila = mysqli_fetch_assoc($resultado)): ?>
                    <tr <?php if($fila['cantidad'] < 5) echo "bgcolor='#ffe6e6'"; // Alerta roja si hay poco stock ?>>
                        <td><?php echo htmlspecialchars($fila['nombre']); ?></td>
                        <td>$ <?php echo number_format($fila['precio'], 2); ?></td>
                        
                        <td align="center" style="font-size: 1.2em;">
                            <?php echo $fila['cantidad']; ?>
                        </td>
                        
                        <td align="center">
                            <a href="views/editar.php?id=<?php echo $fila['id']; ?>">Editar</a>
                            | 
                            <a href="index.php?eliminar=<?php echo $fila['id']; ?>" 
                               onclick="return confirm('¿Eliminar del sistema?');" style="color: red;">Eliminar</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" align="center">Inventario vacío.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>