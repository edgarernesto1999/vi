<?php
$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$patron = "%" . $busqueda . "%";

$sql_leer = "SELECT * FROM productos WHERE nombre LIKE ? ORDER BY nombre ASC";
$stmt_leer = mysqli_prepare($conn, $sql_leer);
mysqli_stmt_bind_param($stmt_leer, "s", $patron);
mysqli_stmt_execute($stmt_leer);

$resultado = mysqli_stmt_get_result($stmt_leer);

