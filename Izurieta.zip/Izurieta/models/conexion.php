<?php  
$server="localhost";
$username="root";
$pass="";
$dbname="sistem";

$conn=mysqli_connect($server,$username,$pass,$dbname);

if(!$conn){
    echo "error de conexion";
}
?>