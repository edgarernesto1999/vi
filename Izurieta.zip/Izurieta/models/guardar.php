<?php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['accion']) && $_POST['accion'] == 'guardar') {
    
    $nombre = trim($_POST['nombre']);
    $cantidad = (int)$_POST['cantidad'];
    $precio = (float)$_POST['precio'];

    if (!empty($nombre) && $cantidad > 0 && $precio >= 0) {
        
        
        $sql = "INSERT INTO productos (nombre, cantidad, precio) VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE cantidad = cantidad + ?, precio = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        
        mysqli_stmt_bind_param($stmt, "sidid", $nombre, $cantidad, $precio, $cantidad, $precio);
        
        if(mysqli_stmt_execute($stmt)){
            header("Location: index.php");
            exit;
        } else {
            echo "Error al guardar: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}
?>
