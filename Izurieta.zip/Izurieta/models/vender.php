<?php

$mensaje = ""; 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['accion']) && $_POST['accion'] == 'vender') {
    
    $nombre = trim($_POST['nombre']);
    $cantidad_compra = (int)$_POST['cantidad'];

    if (!empty($nombre) && $cantidad_compra > 0) {
        
        $sql_check = "SELECT * FROM productos WHERE nombre = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "s", $nombre);
        mysqli_stmt_execute($stmt_check);
        $resultado_check = mysqli_stmt_get_result($stmt_check);
        $producto = mysqli_fetch_assoc($resultado_check);
        mysqli_stmt_close($stmt_check);

        if ($producto) {
            if ($producto['cantidad'] >= $cantidad_compra) {
                
                $sql_restar = "UPDATE productos SET cantidad = cantidad - ? WHERE id = ?";
                $stmt_restar = mysqli_prepare($conn, $sql_restar);
                mysqli_stmt_bind_param($stmt_restar, "ii", $cantidad_compra, $producto['id']);
                
                if (mysqli_stmt_execute($stmt_restar)) {
                    $total_pagar = $producto['precio'] * $cantidad_compra;
                    
                    $mensaje = "<div>
                                    <strong>¡Venta Exitosa!</strong><br>
                                    Producto: $nombre<br>
                                    Cantidad: $cantidad_compra<br>
                                    <strong>TOTAL A PAGAR: $ " . number_format($total_pagar, 2) . "</strong>
                                </div>";
                } else {
                    $mensaje = "<div style='color: red;'>Error al actualizar la base de datos.</div>";
                }
                mysqli_stmt_close($stmt_restar);

            } else {
                $mensaje = "<div>
                                <strong>Error: Stock Insuficiente</strong><br>
                                Solo tienes " . $producto['cantidad'] . " unidades de $nombre.
                            </div>";
            }
        } else {
            $mensaje = "<div>
                            <strong>Error:</strong> El producto '$nombre' no existe en el inventario.
                        </div>";
        }
    }
}
?>