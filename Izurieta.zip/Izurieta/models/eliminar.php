<?php
if (isset($_GET['eliminar'])) {
    $id = (int)$_GET['eliminar'];
    $sql_borrar = "DELETE FROM productos WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $sql_borrar);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if(mysqli_stmt_execute($stmt)) {
        header("Location: index.php"); 
        exit;
    } else {
        echo "Error al eliminar: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}
?>