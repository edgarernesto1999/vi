<?php
// views/editar.php

// 1. Salimos de 'views' (../) para entrar a 'models'
include '../models/conexion.php';

$id_producto = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$producto = null;

if ($id_producto > 0) {
    $sql = "SELECT * FROM productos WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_producto);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $producto = mysqli_fetch_assoc($resultado);
}

if (!$producto) {
    // Si no encuentra, sale de 'views' para ir al index
    header("Location: ../index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
</head>
<body>

    <h2>Editar Producto</h2>

    <form action="../index.php" method="POST">
        <input type="hidden" name="accion" value="editar">
        <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">

        <label>Nombre:</label><br>
        <input type="text" name="nombre" value="<?php echo $producto['nombre']; ?>" required><br><br>

        <label>Precio Unitario:</label><br>
        <input type="number" step="0.01" name="precio" value="<?php echo $producto['precio']; ?>" required min="0"><br><br>

        <label>Cantidad:</label><br>
        <input type="number" name="cantidad" value="<?php echo $producto['cantidad']; ?>" required min="1"><br><br>

        <button type="submit">Actualizar Datos</button>
        
        <a href="../index.php">Cancelar</a>
    </form>

</body>
</html>