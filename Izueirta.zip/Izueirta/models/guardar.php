<?php
// models/guardar.php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['accion']) && $_POST['accion'] == 'guardar') {
    
    $nombre = trim($_POST['nombre']);
    $cantidad = (int)$_POST['cantidad'];
    $precio = (float)$_POST['precio']; // Nuevo campo

    if (!empty($nombre) && $cantidad > 0 && $precio >= 0) {
        
        // SQL MAGICO: 
        // 1. Inserta (nombre, cantidad, precio).
        // 2. Si ya existe el nombre: Suma la cantidad y ACTUALIZA el precio al nuevo.
        $sql = "INSERT INTO productos (nombre, cantidad, precio) VALUES (?, ?, ?) 
                ON DUPLICATE KEY UPDATE cantidad = cantidad + ?, precio = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        
        // "sidid": String(nombre), Int(cant), Double(precio), Int(cant para sumar), Double(precio nuevo)
        mysqli_stmt_bind_param($stmt, "sidid", $nombre, $cantidad, $precio, $cantidad, $precio);
        
        if(mysqli_stmt_execute($stmt)){
            // Guardado exitoso, recarga index
            header("Location: index.php");
            exit;
        } else {
            echo "Error al guardar: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}
?>