<?php
// models/logica_editar.php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['accion']) && $_POST['accion'] == 'editar') {
    
    $id = (int)$_POST['id'];
    $nombre = trim($_POST['nombre']);
    $cantidad = (int)$_POST['cantidad'];
    $precio = (float)$_POST['precio']; // Nuevo campo

    if (!empty($nombre) && $cantidad > 0 && $precio >= 0) {
        // Actualizamos nombre, cantidad y precio
        $sql = "UPDATE productos SET nombre = ?, cantidad = ?, precio = ? WHERE id = ?";
        
        $stmt = mysqli_prepare($conn, $sql);
        // "sidi": String, Int, Double, Int
        mysqli_stmt_bind_param($stmt, "sidi", $nombre, $cantidad, $precio, $id);
        
        if(mysqli_stmt_execute($stmt)){
            header("Location: index.php");
            exit;
        } else {
            echo "Error al actualizar: " . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
}
?>