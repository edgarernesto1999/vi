<?php
// models/vender.php

$mensaje = ""; // Variable para mostrar alertas (Exito o Error)

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['accion']) && $_POST['accion'] == 'vender') {
    
    $nombre = trim($_POST['nombre']);
    $cantidad_compra = (int)$_POST['cantidad'];

    if (!empty($nombre) && $cantidad_compra > 0) {
        
        // 1. PRIMERO CONSULTAMOS SI EXISTE Y CUANTO HAY
        $sql_check = "SELECT * FROM productos WHERE nombre = ?";
        $stmt_check = mysqli_prepare($conn, $sql_check);
        mysqli_stmt_bind_param($stmt_check, "s", $nombre);
        mysqli_stmt_execute($stmt_check);
        $resultado_check = mysqli_stmt_get_result($stmt_check);
        $producto = mysqli_fetch_assoc($resultado_check);
        mysqli_stmt_close($stmt_check);

        if ($producto) {
            // El producto existe, ahora verificamos stock
            if ($producto['cantidad'] >= $cantidad_compra) {
                
                // 2. HAY STOCK SUFICIENTE: RESTAMOS
                $sql_restar = "UPDATE productos SET cantidad = cantidad - ? WHERE id = ?";
                $stmt_restar = mysqli_prepare($conn, $sql_restar);
                mysqli_stmt_bind_param($stmt_restar, "ii", $cantidad_compra, $producto['id']);
                
                if (mysqli_stmt_execute($stmt_restar)) {
                    // CALCULO DEL TOTAL A PAGAR
                    $total_pagar = $producto['precio'] * $cantidad_compra;
                    
                    $mensaje = "<div>
                                    <strong>¡Venta Exitosa!</strong><br>
                                    Producto: $nombre<br>
                                    Cantidad: $cantidad_compra<br>
                                    <strong>TOTAL A PAGAR: $ " . number_format($total_pagar, 2) . "</strong>
                                </div>";
                } else {
                    $mensaje = "<div style='color: red;'>Error al actualizar la base de datos.</div>";
                }
                mysqli_stmt_close($stmt_restar);

            } else {
                // NO HAY STOCK SUFICIENTE
                $mensaje = "<div>
                                <strong>Error: Stock Insuficiente</strong><br>
                                Solo tienes " . $producto['cantidad'] . " unidades de $nombre.
                            </div>";
            }
        } else {
            // EL PRODUCTO NO EXISTE
            $mensaje = "<div>
                            <strong>Error:</strong> El producto '$nombre' no existe en el inventario.
                        </div>";
        }
    }
}
?>