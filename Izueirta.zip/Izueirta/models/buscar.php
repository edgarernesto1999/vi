<?php
// Recogemos el término de búsqueda si existe
$busqueda = isset($_GET['busqueda']) ? $_GET['busqueda'] : '';
$patron = "%" . $busqueda . "%";

// Preparamos la consulta
$sql_leer = "SELECT * FROM productos WHERE nombre LIKE ? ORDER BY nombre ASC";
$stmt_leer = mysqli_prepare($conn, $sql_leer);
mysqli_stmt_bind_param($stmt_leer, "s", $patron);
mysqli_stmt_execute($stmt_leer);

// Guardamos el resultado en una variable que usará el index.php
$resultado = mysqli_stmt_get_result($stmt_leer);
