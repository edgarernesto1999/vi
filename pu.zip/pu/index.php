<?php include "conexion.php"; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CRUD PHP</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h1>Gestión de Personas</h1>

<!-- BUSCADOR -->
<form action="buscar.php" method="GET" class="buscar-form">
    <input type="text" name="q" placeholder="Buscar por cédula o nombre..." required>
    <button type="submit">Buscar</button>
</form>

<a href="crear.php" class="btn crear-btn">+ Nueva Persona</a>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Cédula</th>
            <th>Nombre</th>
            <th>Calificación</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>

<?php
$sql = "SELECT * FROM personas ORDER BY id DESC";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()):
?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['cedula'] ?></td>
            <td><?= $row['nombre'] ?></td>
            <td><?= $row['notas'] ?></td>
            <td>
                <a class="btn editar" href="editar.php?id=<?= $row['id'] ?>">Editar</a>
                <a class="btn eliminar" href="eliminar.php?id=<?= $row['id'] ?>" onclick="return confirm('¿Eliminar registro?');">Eliminar</a>
            </td>
        </tr>
<?php endwhile; ?>

    </tbody>
</table>

</body>
</html>
