<?php
include "conexion.php";

$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$calificacion = $_POST['notas'];

$sql = "INSERT INTO personas (cedula, nombre, notas) VALUES ('$cedula', '$nombre', '$calificacion')";

if ($conn->query($sql)) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>
