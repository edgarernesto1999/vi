<?php
include "conexion.php";

$q = $_GET['q'];
$q = $conn->real_escape_string($q);

$sql = "SELECT * FROM personas 
        WHERE cedula LIKE '%$q%' 
        OR nombre LIKE '%$q%' 
        ORDER BY id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Resultados de búsqueda</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h2>Resultados para: <span class="resaltar"><?= $q ?></span></h2>

<a href="index.php" class="btn volver">← Volver al listado</a>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Cédula</th>
            <th>Nombre</th>
            <th>Calificación</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>

<?php if ($result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= $row['cedula'] ?></td>
            <td><?= $row['nombre'] ?></td>
            <td><?= $row['notas'] ?></td>
            <td>
                <a class="btn editar" href="editar.php?id=<?= $row['id'] ?>">Editar</a>
                <a class="btn eliminar" href="eliminar.php?id=<?= $row['id'] ?>" onclick="return confirm('¿Eliminar?');">Eliminar</a>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
        <tr>
            <td colspan="5" class="no-results">No se encontraron resultados</td>
        </tr>
<?php endif; ?>

    </tbody>
</table>

</body>
</html>

