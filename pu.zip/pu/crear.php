<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva Persona</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h2>Registrar Persona</h2>

<form action="guardar.php" method="POST" class="form">
    <label>Cédula:</label>
    <input type="text" name="cedula" required>

    <label>Nombre:</label>
    <input type="text" name="nombre" required>

    <label>Calificación:</label>
    <input type="number" name="calificacion" min="0" max="20" required>

    <button type="submit" class="btn guardar">Guardar</button>
    <a href="index.php" class="btn volver">Volver</a>
</form>

</body>
</html>
