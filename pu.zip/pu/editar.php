<?php
include "conexion.php";
$id = $_GET['id'];

$sql = "SELECT * FROM personas WHERE id = $id";
$res = $conn->query($sql);
$data = $res->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

<h2>Editar Persona</h2>

<form action="actualizar.php" method="POST" class="form">
    <input type="hidden" name="id" value="<?= $data['id'] ?>">

    <label>Cédula:</label>
    <input type="text" name="cedula" value="<?= $data['cedula'] ?>" required>

    <label>Nombre:</label>
    <input type="text" name="nombre" value="<?= $data['nombre'] ?>" required>

    <label>Calificación:</label>
    <input type="number" name="notas" min="0" max="20" value="<?= $data['notas'] ?>" required>

    <button type="submit" class="btn guardar">Actualizar</button>
    <a href="index.php" class="btn volver">Volver</a>
</form>

</body>
</html>
