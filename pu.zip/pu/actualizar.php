<?php
include "conexion.php";

$id = $_POST['id'];
$cedula = $_POST['cedula'];
$nombre = $_POST['nombre'];
$calificacion = $_POST['notas'];

$sql = "UPDATE personas SET cedula='$cedula', nombre='$nombre', notas='$calificacion' WHERE id=$id";

if ($conn->query($sql)) {
    header("Location: index.php");
} else {
    echo "Error: " . $conn->error;
}
?>
